module.exports = {
  webpack: {
    entry: './src/index.jsx',
  },
};
